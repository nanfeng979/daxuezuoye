export class BootScene extends Phaser.Scene {

  constructor() {
    super({
      key: 'BootScene'
    });
  }

  preload(): void {
    this.load.setPath('assets');
    this.load.atlas("assets", "breakout.png", "breakout.json");
    this.load.audio('bass', [ 'bass.ogg', 'bass.mp3' ]);
  }

  update(): void {
    this.scene.start('PlayScene');
  }
  
}
