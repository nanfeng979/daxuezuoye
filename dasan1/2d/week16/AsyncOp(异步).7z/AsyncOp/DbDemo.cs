using System;
using UnityEngine;
using SQLite;

//AsyncDemo
public class DbDemo : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        DatabaseHandler helper = DatabaseHandler.Instance;
        helper.AddStocks();
        helper.GetStocks();
        GetAsyncData();


    }

    public async void  GetAsyncData()
    {
        var db = new SQLiteAsyncConnection(@"Assets/StreamingAssets/study2.db");
        await db.CreateTableAsync<Stock>();
        var stock = new Stock()
        {
            Symbol = "AAPL"
        };

        await db.InsertAsync(stock);
        var query = db.Table<Stock>().Where(v => v.Symbol.StartsWith("A"));
        var result = await query.ToListAsync();

        foreach (var s in result)
            Debug.Log(stock);
     
    }
}
[Table("Stocks")]
public class Stock
{
    [PrimaryKey, AutoIncrement]
    [Column("id")]
    public int Id { get; set; }

    [Column("symbol")]
    public string Symbol { get; set; }
    public override string ToString()
    {
        return string.Format("(Id={0}, Symbol={1})", Id, Symbol);
    }
}
/*
[Table("Valuations")]
public class Valuation
{
    [PrimaryKey, AutoIncrement]
    [Column("id")]
    public int Id { get; set; }

    [Indexed]
    [Column("stock_id")]
    public int StockId { get; set; }

    [Column("time")]
    public DateTime Time { get; set; }

    [Column("price")]
    public decimal Price { get; set; }
}*/
public class DatabaseHandler
{

    private SQLiteConnection _db;
    static DatabaseHandler _instance = new DatabaseHandler();
    public static DatabaseHandler Instance
    {
        get
        {
            return _instance;
        }
    }
    private DatabaseHandler()
    {

        _db = new SQLiteConnection(@"Assets/StreamingAssets/study.db");
        _db.DropTable<Stock>();
        _db.CreateTable<Stock>();

    }
    public void AddStocks()
    {
        _db.BeginTransaction();

        var stock = new Stock
        {
            Symbol = "MSFT"
        };

        _db.Insert(stock);
        stock = new Stock
        {
            Symbol = "GOOG"
        };
        _db.Insert(stock);
        _db.Commit();
    }
    public void GetStocks()
    {
        var stocks = _db.Query<Stock>("SELECT * FROM Stocks");
        Debug.Log(stocks.Count);

        foreach (var stock in stocks)
        {
            Debug.Log(stock);
        }
    }
  
}
